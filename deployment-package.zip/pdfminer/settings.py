STRICT = False
